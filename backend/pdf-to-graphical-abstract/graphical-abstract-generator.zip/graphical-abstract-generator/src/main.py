def main():
    print("Welcome to the Graphical Abstract Generator!")
    
    # Step 1: Text Extraction
    from text_extraction.extractor import Extractor
    extractor = Extractor()
    
    research_paper_text = input("Please enter the research paper text: ")
    title = extractor.extract_title(research_paper_text)
    key_findings = extractor.extract_key_findings(research_paper_text)
    methods = extractor.extract_methods(research_paper_text)
    conclusion = extractor.extract_conclusion(research_paper_text)
    
    # Step 2: User Customization
    from customization.customizer import Customizer
    customizer = Customizer()
    
    color_scheme = input("Choose a color scheme (dark, light, custom): ")
    layout = input("Choose a layout style (vertical, horizontal, mind-map): ")
    design_type = input("Choose a design type (icon-based, text-heavy): ")
    
    customizer.set_color_scheme(color_scheme)
    customizer.set_layout(layout)
    customizer.set_design_type(design_type)
    
    # Step 3: Visualization
    from visualization.visualizer import Visualizer
    visualizer = Visualizer()
    
    visualizer.create_charts(key_findings)
    visualizer.overlay_text(title, methods, conclusion)
    visualizer.generate_illustration()
    
    print("Graphical abstract generated successfully!")

if __name__ == "__main__":
    main()